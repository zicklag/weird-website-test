import{default as t}from"../entry/_page.svelte.fa68830c.js";export{t as component};
