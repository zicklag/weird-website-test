import{default as t}from"../entry/error.svelte.c84d7ff5.js";export{t as component};
